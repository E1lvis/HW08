package edu.uncc.hw08;

public class User {
    String uid, name, email, docID;

    public User(String uid, String name, String email, String docID) {
        this.uid = uid;
        this.name = name;
        this.email = email;
        this.docID = docID;
    }

    public User(String uid, String name, String email) {
        this.uid = uid;
        this.name = name;
        this.email = email;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDocID() {
        return docID;
    }

    public void setDocID(String docID) {
        this.docID = docID;
    }

    public User() {
    }

    @Override
    public String toString() {
        return name;
    }
}
