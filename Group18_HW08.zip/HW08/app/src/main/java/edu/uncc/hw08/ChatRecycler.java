package edu.uncc.hw08;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.lang.reflect.Array;
import java.util.ArrayList;

import edu.uncc.hw08.databinding.ChatListItemBinding;

public class ChatRecycler extends RecyclerView.Adapter<ChatRecycler.ChatViewHolder> {
    ArrayList<Message> messages = new ArrayList<>();

    public ChatRecycler(ArrayList<Message> messagesList){
        messages = messagesList;
    }

    @NonNull
    @Override
    public ChatRecycler.ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_list_item, parent, false);

        ChatViewHolder chatViewHolder = new ChatViewHolder(view);
        return chatViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ChatRecycler.ChatViewHolder holder, int position) {
        Message message = messages.get(position);

        // set textviews etc
        holder.from.setText(message.getCreatedby());
        holder.text.setText(message.getMessage());
        holder.time.setText(message.getCreatedAt());

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        if (message.getCreatedByID().equals(user.getUid())){
            holder.delete.setVisibility(View.VISIBLE);
            holder.delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // delete message
                    db.collection("chatMessages").document(message.getId()).delete();
                    messages.remove(message);
                    notifyDataSetChanged();
                }
            });
        } else {
            holder.delete.setVisibility(View.INVISIBLE);
        }


    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public class ChatViewHolder extends RecyclerView.ViewHolder{
        TextView from;
        TextView text;
        TextView time;
        ImageView delete;

        public ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            from = itemView.findViewById(R.id.textViewMsgBy);
            text = itemView.findViewById(R.id.textViewMsgText);
            time = itemView.findViewById(R.id.textViewMsgOn);
            delete = itemView.findViewById(R.id.imageViewDelete);
        }
    }
}
