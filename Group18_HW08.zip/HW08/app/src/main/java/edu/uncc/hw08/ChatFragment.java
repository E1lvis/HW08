package edu.uncc.hw08;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import edu.uncc.hw08.databinding.FragmentChatBinding;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ChatFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ChatFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";

    // TODO: Rename and change types of parameters
    private chatSession mParam1;
    ArrayList<Message> messages;

    public ChatFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @return A new instance of fragment ChatFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ChatFragment newInstance(chatSession param1) {
        ChatFragment fragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_PARAM1, param1);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = (chatSession) getArguments().getSerializable(ARG_PARAM1);
            messages = mParam1.getMessages();
        }
    }

    FragmentChatBinding binding;
    RecyclerView recyclerView;
    ChatRecycler recycler;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentChatBinding.inflate(inflater, container, false);

        recyclerView = binding.getRoot().findViewById(R.id.recyclerView);
        recycler = new ChatRecycler(messages);
        recyclerView.setAdapter(recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference ref = db.collection("chatSession").document();
        DocumentReference messagesREF = db.collection("chatSession")
                .document(ref.getId())
                .collection("chatMessages")
                .document();

        Button close = view.findViewById(R.id.buttonClose);
        Button submit = view.findViewById(R.id.buttonSubmit);
        EditText enterMessage = view.findViewById(R.id.editTextMessage);
        Button deleteChat = view.findViewById(R.id.buttonDeleteChat);

        deleteChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.collection("chatSession").document(mParam1.getSessionID()).delete();
                listener.close();
            }
        });

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.close();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // check for valid input
                if (!enterMessage.getText().toString().isEmpty()){
                    // message valid, save message, add to list, and refresh list
                    //setting data for message
                    LocalDateTime dt;
                    dt = LocalDateTime.now();

                    String date = dt.getMonth() + " " + dt.getDayOfMonth() + " " + dt.getYear() + " " + dt.getHour() + ":" + dt.getMinute();
                    Message message = new Message(date, enterMessage.getText().toString(), messagesREF.getId(), user.getDisplayName(), user.getUid(), ref.getId());

                    db.collection("chatSession").document(mParam1.sessionID).collection("chatMessages").add(message);
                    Log.d("TAG", String.valueOf(mParam1.getMessages().size()) + " message list size: " + String.valueOf(messages.size()));
                    // put the last message first


                    enterMessage.getText().clear();




                } else {
                    Toast.makeText(getContext(), "Please enter a message", Toast.LENGTH_SHORT);
                }
            }
        });

       //recycler.notifyDataSetChanged();


    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        listener = (ChatFragment.actionListener) context;
    }

    actionListener listener;

    interface actionListener{
        void close();
    }


}