
/*TO DO NOTEs
* Check if user is online */
package edu.uncc.hw08;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.time.LocalDateTime;
import java.util.HashMap;

import edu.uncc.hw08.databinding.FragmentCreateChatBinding;
import edu.uncc.hw08.databinding.UsersRowItemBinding;

//HW08_SkeletonApp/HW08/key

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CreateChatFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CreateChatFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    ArrayList<User> users = new ArrayList<>();
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    LocalDateTime dt;
    int selectedIndex;

    public CreateChatFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CreateChatFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CreateChatFragment newInstance(String param1, String param2) {
        CreateChatFragment fragment = new CreateChatFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    FragmentCreateChatBinding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentCreateChatBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.pop();
            }
        });

        binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String chat = binding.editTextMessage.getText().toString();
                String selectedUser = binding.textViewSelectedUser.getText().toString();

                if(chat.isEmpty() || selectedUser.equals("No User Selected !!")){
                    Toast.makeText(getContext(), "Select user and enter message", Toast.LENGTH_SHORT).show();
                }else{


                    //Right now, Im creating a collection with a doc which holds the ids of the users and the doc
                    //and a collection with the actual messages
                    FirebaseFirestore db = FirebaseFirestore.getInstance();
                    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                    //initial collection, only holds uid and uid2
                    DocumentReference ref = db.collection("chatSession").document();
                    //messages collection, add the message to this
                    DocumentReference messagesREF = db.collection("chatSession")
                            .document(ref.getId())
                            .collection("chatMessages")
                            .document();

                    //to grab chosen user id get selected index and use that grab same index in user array
                    HashMap<String, Object> sessionData = new HashMap<>();
                    //user is the actual user using the app and creating the chat
                    sessionData.put("uid1", user.getUid());
                    sessionData.put("uid2", users.get(selectedIndex).getUid());
                    sessionData.put("sessionID", ref.getId());
                    //setting session data
                    ref.set(sessionData).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Log.d("TAG", "onComplete: SESSIONS DATA SET");
                            }else{
                                Log.d("TAG", "onComplete: " + task.getException().toString());}


                        }
                    });

                    //setting data for message
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        dt = LocalDateTime.now();
                    }
                    HashMap<String, Object> data = new HashMap<>();
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        data.put("createdAt", dt.getMonth().toString() + " " + dt.getDayOfMonth() + ", " + dt.getYear() + " " + dt.getHour() + ":" + dt.getMinute());
                    }
                    data.put("message", chat);
                    data.put("id", messagesREF.getId());
                    data.put("createdby", user.getDisplayName());
                    data.put("createdByID", user.getUid());
                    data.put("sessionID", ref.getId());


                    messagesREF.set(data).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Log.d("TAG", "onComplete: MESSAGE DATA SET");
                                mListener.pop();
                                //on success condition
                            }  else{
                                Log.d("TAG", "onComplete: " + task.getException().toString());}
                        }
                    });
                }

            }
        });
        ListView list = binding.listView;
        adapter = new usersRowAdapter(getActivity(), R.layout.users_row_item, users);
        list.setAdapter(adapter);
        getData();

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                binding.textViewSelectedUser.setText(list.getItemAtPosition(i).toString());
                selectedIndex = i;
            }
        });
    }

    usersRowAdapter adapter;
    createChatListener mListener;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (createChatListener) context;
    }

    interface createChatListener{
        void pop();
    }
    private void getData(){
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        db.collection("Users")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        users.clear();
                        for(QueryDocumentSnapshot UserRecieved : value){
                            User user = UserRecieved.toObject(User.class);
                            //making sure we dont add current user
                            if (!(user.getUid().equals(currentUser.getUid()))){
                                users.add(user);
                            }
                        }
                        adapter.notifyDataSetChanged();
                    }
                });
    }

}