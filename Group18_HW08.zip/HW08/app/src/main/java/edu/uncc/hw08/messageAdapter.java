package edu.uncc.hw08;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

// class was supposed to be chat sessions not messages
//
public class messageAdapter extends ArrayAdapter<chatSession> {
    public messageAdapter(@NonNull Context context, int resource, @NonNull ArrayList<chatSession> sessions) {
        super(context, resource, sessions);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.my_chats_list_item, parent, false);



        }



        TextView msgBy = convertView.findViewById(R.id.textViewMsgBy);
        TextView text = convertView.findViewById(R.id.textViewMsgText);
        TextView msgOn = convertView.findViewById(R.id.textViewMsgOn);

        chatSession temp = getItem(position);
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        db.collection("Users")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        for(QueryDocumentSnapshot UserRecieved : value){
                            User user = UserRecieved.toObject(User.class);
                            //display chat sessions for the current user

                            // remove chat sessions that arent the current user's or that the current user isnt a part of
                            if (currentUser != null){
                                if (!(currentUser.getUid().equals(temp.getUid1()) || currentUser.getUid().equals(temp.getUid2()))){
                                    remove(temp);

                                } else if (temp.getUid2().equals(user.getUid())){

                                    // chat session belongs to the user (i.e. created by the current user)
                                    // set msgBy to the recipient of the message
                                    msgBy.setText(user.getName());
                                }
                            }



                        }
                        notifyDataSetChanged();
                    }
                });



        // most recent message from chat session
        String latestMessage = temp.getMessages().get(temp.getMessages().size() - 1).getMessage();
        text.setText(latestMessage);

        String time = temp.getMessages().get(temp.getMessages().size() - 1).getCreatedAt();
        msgOn.setText(time);

        return convertView;
    }
}
