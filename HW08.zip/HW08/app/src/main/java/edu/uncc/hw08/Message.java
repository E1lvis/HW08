package edu.uncc.hw08;

public class Message {
    String createdAt;
    String message;
    String id;
    String createdby;
    String createdByID;
    String sessionID;

    public Message() {
    }

    public Message(String createdAt, String message, String id, String createdby, String createdByID, String sessionID) {
        this.createdAt = createdAt;
        this.message = message;
        this.id = id;
        this.createdby = createdby;
        this.createdByID = createdByID;
        this.sessionID = sessionID;
    }

    public Message(String createdAt, String message, String id, String createdby, String createdByID) {
        this.createdAt = createdAt;
        this.message = message;
        this.id = id;
        this.createdby = createdby;
        this.createdByID = createdByID;
    }



    public Message(String createdAt, String message, String id, String createdby) {
        this.createdAt = createdAt;
        this.message = message;
        this.id = id;
        this.createdby = createdby;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreatedby() {
        return createdby;
    }

    public void setCreatedby(String createdby) {
        this.createdby = createdby;
    }

    public String getCreatedByID() {
        return createdByID;
    }

    public void setCreatedByID(String createdByID) {
        this.createdByID = createdByID;
    }

    @Override
    public String toString() {
        return "Message{" +
                "createdAt='" + createdAt + '\'' +
                ", message='" + message + '\'' +
                ", id='" + id + '\'' +
                ", createdby='" + createdby + '\'' +
                ", createdByID='" + createdByID + '\'' +
                '}';
    }
}
