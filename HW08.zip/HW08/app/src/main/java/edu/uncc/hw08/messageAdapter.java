package edu.uncc.hw08;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class messageAdapter extends ArrayAdapter<Message> {
    public messageAdapter(@NonNull Context context, int resource, @NonNull List<Message> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.chat_list_item, parent, false);



        }
        TextView msgBy = convertView.findViewById(R.id.textViewMsgBy);
        TextView text = convertView.findViewById(R.id.textViewMsgText);
        TextView msgOn = convertView.findViewById(R.id.textViewMsgOn);

        Message temp = getItem(position);

        msgBy.setText("PLACEHOLDER");
        text.setText(temp.getMessage());
        msgOn.setText(temp.getCreatedAt());
        return convertView;
    }
}
