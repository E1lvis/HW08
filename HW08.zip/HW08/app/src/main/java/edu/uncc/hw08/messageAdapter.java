package edu.uncc.hw08;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class messageAdapter extends ArrayAdapter<Message> {
    public messageAdapter(@NonNull Context context, int resource, @NonNull List<Message> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.chat_list_item, parent, false);



        }



        TextView msgBy = convertView.findViewById(R.id.textViewMsgBy);
        TextView text = convertView.findViewById(R.id.textViewMsgText);
        TextView msgOn = convertView.findViewById(R.id.textViewMsgOn);

        Message temp = getItem(position);
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if(currentUser.getUid().equals(temp.getCreatedByID())){
            Log.d("TAG", "getView: " +currentUser.getUid() + " " +  temp.getCreatedByID());
            msgBy.setText("Me");
        }else{
            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("Users")
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                            for(QueryDocumentSnapshot UserRecieved : value){
                                User user = UserRecieved.toObject(User.class);
                                //making sure we dont add current user
                                if (temp.getCreatedByID().equals( user.getUid())){

                                    msgBy.setText(user.getName());
                                }

                            }
                        }
                    });
        }


        text.setText(temp.getMessage());
        msgOn.setText(temp.getCreatedAt());
        return convertView;
    }
}
