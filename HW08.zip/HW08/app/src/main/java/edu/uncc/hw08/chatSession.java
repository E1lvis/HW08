package edu.uncc.hw08;

import java.util.ArrayList;

public class chatSession {
    //UID1 is who started the chat, 2 being the one getting the message
    String uid1;
    String uid2;

    public chatSession() {
    }

    String sessionID;
    //the actual messages
    ArrayList<Message> messages;

    public chatSession(String uid1, String uid2) {
        this.uid1 = uid1;
        this.uid2 = uid2;
    }

    public String getUid1() {
        return uid1;
    }

    public void setUid1(String uid1) {
        this.uid1 = uid1;
    }

    public String getUid2() {
        return uid2;
    }

    public void setUid2(String uid2) {
        this.uid2 = uid2;
    }

    public ArrayList<Message> getMessages() {
        return messages;
    }

    public void setMessages(ArrayList<Message> messages) {
        this.messages = messages;
    }

    public String getSessionID() {
        return sessionID;
    }

    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }

    @Override
    public String toString() {
        return "chatSession{" +
                "uid1='" + uid1 + '\'' +
                ", uid2='" + uid2 + '\'' +
                ", sessionID='" + sessionID + '\'' +
                ", messages=" + messages +
                '}';
    }
}
