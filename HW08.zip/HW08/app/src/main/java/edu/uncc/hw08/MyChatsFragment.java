package edu.uncc.hw08;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.checkerframework.checker.units.qual.A;

import java.util.ArrayList;

import edu.uncc.hw08.databinding.FragmentMyChatsBinding;
/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MyChatsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MyChatsFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    ArrayList<chatSession> sessions = new ArrayList<>();
    ArrayList<Message> messages = new ArrayList<>();
    public MyChatsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MyChatsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MyChatsFragment newInstance(String param1, String param2) {
        MyChatsFragment fragment = new MyChatsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    FragmentMyChatsBinding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentMyChatsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                mListener.logout();
            }
        });

        binding.buttonNewChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.createChat();

            }
        });
        ListView list = binding.listView;
        adapter = new messageAdapter(getActivity(), R.layout.chat_list_item, messages);
        list.setAdapter(adapter);
        getData();




    }
    //need to create an arary list of final messages that incluede the current user
    messageAdapter adapter;
    myChatListener mListener;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        mListener = (MyChatsFragment.myChatListener) context;
    }

    interface myChatListener{
        void logout();
        void createChat();
    }

    private void getData(){
        messages.clear();
        sessions.clear();
        //grab the chat sessions, convert them to chat Session objects, then convert the messages to messages objects
        //add the messages to the current shat session object array
        //add session session array
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("chatSession")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        for(QueryDocumentSnapshot SessionRecieved : value){
                            chatSession tempSession = SessionRecieved.toObject(chatSession.class);
                            ArrayList<Message> tempMessages = new ArrayList<>();
                            //Log.d("TAG", "onEvent: VALUE: " + SessionRecieved.getData());

                            db.collection("chatSession")
                                    .document(SessionRecieved.getId())
                                    .collection("chatMessages").addSnapshotListener(new EventListener<QuerySnapshot>() {
                                @Override
                                public void onEvent(@Nullable QuerySnapshot val, @Nullable FirebaseFirestoreException error) {
                                    //converting messages to message objects, once all converted, add temp array to current
                                    //session object, then add that object to sessions array
                                    for(QueryDocumentSnapshot mes : val){
                                        Message tempMes = mes.toObject(Message.class);
                                        //Log.d("TAG", "getData: inside message loop " + tempMes.toString());
                                        tempMessages.add(tempMes);
                                        //Log.d("TAG", "onEvent: VALMES: " + mes.getData());
                                    }

                                    tempSession.setMessages(tempMessages);
                                    sessions.add(tempSession);

                                    if(user.getUid().equals(tempSession.getUid1()) || user.getUid().equals(tempSession.getUid2()) ){
                                        ArrayList<Message> temp = tempSession.getMessages();
                                        Log.d("TAG", "onEvent: add to messages array" + tempSession.getMessages().size());
                                        messages.add(temp.get(temp.size()-1));
                                        adapter.notifyDataSetChanged();

                                    }
                                    /*
                                    Log.d("TAG", "getDatafortempMEsa: " + tempMessages.toString());

                                    Log.d("TAG", "getDataSessionSize: " + sessions.size());
                                    Log.d("TAG", "getDatatempSession.toString: " + tempSession.toString());

                                     */

                                }
                            });



                        }

                    }

                    //call to update last message array
                });





        //db.collection("chatMessages").document("chatMessages")



    }

   }